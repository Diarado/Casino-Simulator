open OUnit2
open Game

let string_of_rank_test (name : string) (rk : Blackjack.rank)
    (expected_output : string) : test =
  name >:: fun _ -> assert_equal expected_output (Blackjack.string_of_rank rk)

let string_of_rank_tests = [ string_of_rank_test "trivial case 0 to 0" Two "2" ]
let tests = "test suite for A1" >::: List.flatten [ string_of_rank_tests ]
let _ = run_test_tt_main tests
