open Game
open Blackjack

let rec game_loop (deck : deck) (player_hand : hand) (dealer_hand : hand) : unit
    =
  match player_turn deck player_hand with
  | x, y -> (
      let player_hand' = x in
      let deck = y in
      let dealer_hand' = dealer_turn deck dealer_hand in
      match (player_hand', dealer_hand') with
      | [], _ -> (
          print_endline "\nYou lose!";
          print_endline "Play again? (yes or no)";
          match read_line () with
          | "yes" ->
              let deck' =
                if List.length deck < 10 then create_deck () else deck
              in
              game_loop
                (deck |> List.tl |> List.tl)
                []
                [ List.hd deck'; List.nth deck' 1 ]
          | "no" -> ()
          | _ -> print_endline "Invalid input.")
      | _, [] -> (
          print_endline "\nYou win!";
          print_endline "Play again? (yes or no)";
          match read_line () with
          | "yes" ->
              let deck' =
                if List.length deck < 10 then create_deck () else deck
              in
              game_loop
                (deck |> List.tl |> List.tl)
                []
                [ List.hd deck'; List.nth deck' 1 ]
          | "no" -> ()
          | _ -> print_endline "Invalid input.")
      | _, _ -> (
          let player_score = score player_hand' in
          let dealer_score = score dealer_hand' in
          if player_score > dealer_score then print_endline "You win!"
          else if player_score < dealer_score then print_endline "You lose!"
          else print_endline "Tie!";
          print_endline ("Your score: " ^ string_of_int player_score);
          print_endline ("Dealer's score: " ^ string_of_int dealer_score);
          print_endline "Play again? (yes or no)";
          match read_line () with
          | "yes" ->
              let deck' =
                if List.length deck < 10 then create_deck () else deck
              in
              game_loop
                (deck |> List.tl |> List.tl)
                []
                [ List.hd deck'; List.nth deck' 1 ]
          | "no" -> ()
          | _ -> print_endline "Invalid input."))

let () =
  Random.self_init ();
  print_endline "Welcome to Blackjack!";
  let deck = create_deck () in
  game_loop (deck |> List.tl |> List.tl) [] [ List.hd deck; List.nth deck 1 ];
  print_endline "Thanks for playing!"
